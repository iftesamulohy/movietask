from django.shortcuts import render
from rest_framework import viewsets

from movies.filters import MovieFilter
from .models import Movie, Rating
from .serializers import MovieSerializer, RatingSerializer
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import filters
from django.db.models import Avg
from django_filters import rest_framework as django_filters
class MovieViewSet(viewsets.ModelViewSet):
    filter_backends = [filters.OrderingFilter, django_filters.DjangoFilterBackend]
    filterset_class = MovieFilter
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    queryset = Movie.objects.all()
    serializer_class = MovieSerializer
    def retrieve(self, request, pk=None):
        queryset = Movie.objects.all()
        movie = self.get_object(queryset, pk)
        ratings = Rating.objects.filter(movie_id=movie.id) 
        average_rating = ratings.aggregate(avg_rating=Avg('rating'))['avg_rating']
        serializer = MovieSerializer(movie)
        data = serializer.data
        data['average_rating'] = average_rating
        return Response(data)

    def get_object(self, queryset, pk):
        try:
            return queryset.get(pk=pk)
        except Movie.DoesNotExist:
            return Response({"message": "Movie not found"}, status=404)

class RatingViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    queryset = Rating.objects.all()
    serializer_class = RatingSerializer
